<?php

namespace App;
use Spatie\Permission\Models\Role as spatie_role;
use Illuminate\Database\Eloquent\Model;

class Role extends spatie_role
{
    /**
     * Get the role's users
     */

}
