<?php

namespace App\Http\Controllers\API;

use App\Enums\Roles;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class NotificationsController extends Controller
{
    /**
     * les conditions de lecture des methodes
     */
    function __construct()
    {
        $agent = Roles::AGENT;
        $recouvreur = Roles::RECOUVREUR;
        $superviseur = Roles::SUPERVISEUR;
        $ges_flotte = Roles::GESTION_FLOTTE;
        $this->middleware("permission:$recouvreur|$superviseur|$ges_flotte|$agent");
    }

    /**
     * ///////Recupérer toutes mes notifications
     */
    public function all_notifications()
    {
        return response()->json([
            'message' => "",
            'status' => true,
            'data' => Auth::user()->notifications->sortByDesc('created_at')
        ]);
    }

    /**
     * /////Recupérer mes notifications non lues
     */
    public function unread_notifications()
    {
        return response()->json([
            'message' => "",
            'status' => true,
            'data' => Auth::user()->unreadNotifications->sortByDesc('created_at')
        ]);
    }

    /**
     * ////marquer comme lue
     */
    public function read_notifications($id)
    {
        $user = Auth::user();
        $my_notifications = $user->unreadNotifications ;

        //on verifi si la notification existe
        if (!$my_notification = $my_notifications->find($id)) {
            return response()->json([
                'message' => "Cette notificaton n'existe pas",
                'status' => false,
                'data' => null
            ]);
        }

        $my_notification->markAsRead();

        return response()->json([
            'message' => "",
            'data' =>  null,
            'status' => true
        ]);
    }

    /**
     * ////marquer comme lue
     */
    public function delete_notifications($id)
    {
        $user = Auth::user();
        $my_notifications = $user->notifications ;

        //on verifi si la notification existe
        if (!$my_notification = $my_notifications->find($id)) {
            return response()->json([
                'message' => "Cette notificaton n'existe pas",
                'status' => false,
                'data' => null
            ]);
        }

        $my_notification->delete();

        return response()->json([
            'message' => "Notification supprimée avec succès",
            'data' => null,
            'status' => true,
        ]);
    }
}
